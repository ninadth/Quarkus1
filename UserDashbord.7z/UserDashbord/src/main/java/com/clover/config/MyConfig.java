package com.clover.config;

import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class MyConfig {
	

// public ModelMapper modelMapper() {
//	 return new ModelMapper();
// }
	
	
}
