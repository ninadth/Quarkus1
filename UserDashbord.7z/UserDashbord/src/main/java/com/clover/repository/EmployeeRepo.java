package com.clover.repository;

import com.clover.entity.Employee;

import io.quarkus.hibernate.orm.panache.PanacheRepository;

public class EmployeeRepo implements  PanacheRepository<Employee>{

}
